import { clsx, type ClassValue } from 'clsx'
import { twMerge } from 'tailwind-merge'

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/** Normalise user-typed batch numbers: trim, uppercase, collapse spaces to hyphens. */
export function normaliseBatch(raw: string) {
  return raw.trim().toUpperCase().replace(/\s+/g, '-').replace(/-+/g, '-')
}
