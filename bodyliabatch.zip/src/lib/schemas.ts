import { z } from 'zod'
import { normaliseBatch } from './utils'

/**
 * Batch format: BDL-<product code>-<YYMM>-<4 digits>, e.g. BDL-FR-2509-0312.
 * Shared verbatim with the BFF (see Book 1) so client and server reject the same input.
 */
export const BATCH_PATTERN = /^BDL-[A-Z]{2}-\d{2}(0[1-9]|1[0-2])-\d{4}$/

export const batchNumberSchema = z
  .string({ required_error: 'Enter the batch number printed on your pack.' })
  .min(1, 'Enter the batch number printed on your pack.')
  .transform(normaliseBatch)
  .refine((v) => v.length <= 20, 'That is longer than a Bodylia batch number.')
  .refine(
    (v) => BATCH_PATTERN.test(v),
    'Batch numbers look like BDL-FR-2509-0312. Check for O/0 and I/1 mix-ups.',
  )

export const batchSearchSchema = z.object({
  batch: batchNumberSchema,
})
export type BatchSearchInput = z.input<typeof batchSearchSchema>

const MAX_PHOTO_BYTES = 5 * 1024 * 1024
const PHOTO_TYPES = ['image/jpeg', 'image/png', 'image/webp']

export const PURCHASE_CHANNELS = [
  'bodylia.in',
  'Amazon',
  'Flipkart',
  'Pharmacy or store',
  'Other',
] as const

export const reportSchema = z.object({
  fullName: z
    .string()
    .trim()
    .min(2, 'Enter your full name.')
    .max(80, 'Name must be 80 characters or fewer.'),
  email: z.string().trim().min(1, 'Enter your email address.').email('Enter an email like name@example.com.'),
  phone: z
    .string()
    .trim()
    .optional()
    .refine((v) => !v || /^(\+91[ -]?)?[6-9]\d{9}$/.test(v.replace(/\s/g, '')), 'Enter a 10-digit Indian mobile number, e.g. 98765 43210.'),
  batch: batchNumberSchema,
  channel: z.enum(PURCHASE_CHANNELS, {
    errorMap: () => ({ message: 'Choose where you bought the pack.' }),
  }),
  photo: z
    .custom<FileList | undefined>()
    .optional()
    .refine((files) => !files || files.length === 0 || PHOTO_TYPES.includes(files[0].type), 'Photo must be a JPG, PNG or WebP image.')
    .refine((files) => !files || files.length === 0 || files[0].size <= MAX_PHOTO_BYTES, 'Photo must be 5 MB or smaller.'),
  message: z
    .string()
    .trim()
    .min(20, 'Tell us a little more — at least 20 characters.')
    .max(1000, 'Keep your message to 1000 characters or fewer.'),
  consent: z.literal(true, {
    errorMap: () => ({ message: 'Confirm we may contact you about this report.' }),
  }),
})
export type ReportInput = z.input<typeof reportSchema>
export type ReportOutput = z.output<typeof reportSchema>

/* ----------------------------- Public ----------------------------- */

export const trackSchema = z.object({
  reference: z
    .string()
    .trim()
    .toUpperCase()
    .min(1, 'Enter the reference from your confirmation email.')
    .regex(/^SR-\d{4}-\d{5}$/, 'References look like SR-2026-04821.'),
  email: z.string().trim().min(1, 'Enter the email you used for the report.').email('Enter an email like name@example.com.'),
})
export type TrackInput = z.infer<typeof trackSchema>

export const feedbackSchema = z.object({
  comment: z.string().trim().max(500, 'Keep your comment to 500 characters or fewer.').optional(),
})
