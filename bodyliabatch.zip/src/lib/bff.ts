import type { BatchRecord } from '../data/batches'
import type { SuspiciousReport } from '../data/admin-seed'
import type { ReportOutput } from './schemas'
import { store } from './store'

/**
 * Browser-side client for the Bodylia BFF (batch.bodylia.in/bff/v1).
 * Mocked here with the same contract as Book 1 §4:
 *   GET  /bff/v1/batches/:batch        → LookupResult
 *   POST /bff/v1/reports               → { reference }
 *   POST /bff/v1/reports/track         → TrackResult
 *   GET  /bff/v1/recalls               → BatchRecord[]
 */

export type LookupResult =
  | { kind: 'genuine'; record: BatchRecord }
  | { kind: 'expired'; record: BatchRecord }
  | { kind: 'recalled'; record: BatchRecord }
  | { kind: 'not_found' }
  | { kind: 'rate_limited'; retryAfterSeconds: number }
  | { kind: 'error' }

const WINDOW_MS = 60_000
let hits: number[] = []
const delay = (ms: number) => new Promise((r) => setTimeout(r, ms))

export async function lookupBatch(batch: string, now: Date = new Date()): Promise<LookupResult> {
  const t = now.getTime()
  const max = store.get().settings.rateLimitPerMinute
  hits = hits.filter((h) => t - h < WINDOW_MS)
  if (hits.length >= max) {
    return { kind: 'rate_limited', retryAfterSeconds: Math.ceil((WINDOW_MS - (t - hits[0])) / 1000) }
  }
  hits.push(t)

  await delay(450)
  if (batch.endsWith('-9999')) return { kind: 'error' }

  const record = store.get().batches.find((b) => b.batch === batch)
  if (!record) return { kind: 'not_found' }
  if (!record.firstCheckedAt) {
    store.set((s) => ({ batches: s.batches.map((b) => (b.batch === batch ? { ...b, firstCheckedAt: now.toISOString() } : b)) }))
  }
  if (record.status === 'recalled') return { kind: 'recalled', record }
  if (new Date(record.expires) < now) return { kind: 'expired', record }
  return { kind: 'genuine', record }
}

export async function submitReport(input: ReportOutput): Promise<{ reference: string }> {
  await delay(600)
  const seq = String(Math.abs(hash(input.email + input.batch + Date.now())) % 100000).padStart(5, '0')
  const reference = `SR-${new Date().getFullYear()}-${seq}`
  const now = new Date().toISOString()
  store.set((s) => ({
    reports: [
      {
        reference,
        fullName: input.fullName,
        email: input.email,
        phone: input.phone || undefined,
        batch: input.batch,
        channel: input.channel,
        message: input.message,
        photoName: input.photo && input.photo.length ? input.photo[0].name : undefined,
        createdAt: now,
        status: 'new',
        timeline: [{ at: now, by: 'Customer', kind: 'received', text: 'Report received via batch.bodylia.in' }],
      },
      ...s.reports,
    ],
  }))
  store.notify(`New report ${reference} is unassigned`, ['support', 'admin'])
  return { reference }
}

export type TrackResult = { found: false } | { found: true; report: SuspiciousReport }

/** Reference AND email must match — never reveals whether a reference exists on its own. */
export async function trackReport(reference: string, email: string): Promise<TrackResult> {
  await delay(450)
  const report = store.get().reports.find((r) => r.reference === reference && r.email.toLowerCase() === email.toLowerCase())
  return report ? { found: true, report } : { found: false }
}

function hash(s: string) {
  let h = 0
  for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0
  return h
}
