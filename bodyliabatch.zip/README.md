# Batch Search Site

Exported from [this design](https://www.magicpatterns.com/os/5vAWPEgE3RmxzRCVSfFfws/3VBH9qz6zvtnsWexP3JeSi) on [Magic Patterns](https://magicpatterns.com).

## Getting started

1. `npm install`
2. `npm run dev`
